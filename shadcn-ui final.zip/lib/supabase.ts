import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

export type Database = {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          password_hash: string
          role: string
          last_login: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          email: string
          password_hash: string
          role?: string
          last_login?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          password_hash?: string
          role?: string
          last_login?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      titles: {
        Row: {
          id: string
          title: string
          slug: string
          type: 'movie' | 'series'
          synopsis: string | null
          year: number | null
          country: string | null
          genres: string[]
          cast_members: string[]
          tags: string[]
          internal_rating: number | null
          duration_minutes: number | null
          status: 'draft' | 'processing' | 'published' | 'hidden'
          poster_url: string | null
          backdrop_url: string | null
          trailer_url: string | null
          trailer_type: 'youtube' | 'vimeo' | 'mp4' | 'external' | null
          views_count: number
          featured: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          slug: string
          type: 'movie' | 'series'
          synopsis?: string | null
          year?: number | null
          country?: string | null
          genres?: string[]
          cast_members?: string[]
          tags?: string[]
          internal_rating?: number | null
          duration_minutes?: number | null
          status?: 'draft' | 'processing' | 'published' | 'hidden'
          poster_url?: string | null
          backdrop_url?: string | null
          trailer_url?: string | null
          trailer_type?: 'youtube' | 'vimeo' | 'mp4' | 'external' | null
          views_count?: number
          featured?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          slug?: string
          type?: 'movie' | 'series'
          synopsis?: string | null
          year?: number | null
          country?: string | null
          genres?: string[]
          cast_members?: string[]
          tags?: string[]
          internal_rating?: number | null
          duration_minutes?: number | null
          status?: 'draft' | 'processing' | 'published' | 'hidden'
          poster_url?: string | null
          backdrop_url?: string | null
          trailer_url?: string | null
          trailer_type?: 'youtube' | 'vimeo' | 'mp4' | 'external' | null
          views_count?: number
          featured?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      episodes: {
        Row: {
          id: string
          title_id: string
          season_number: number
          episode_number: number
          episode_title: string | null
          synopsis: string | null
          duration_minutes: number | null
          status: 'draft' | 'processing' | 'published' | 'hidden'
          thumbnail_url: string | null
          views_count: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title_id: string
          season_number: number
          episode_number: number
          episode_title?: string | null
          synopsis?: string | null
          duration_minutes?: number | null
          status?: 'draft' | 'processing' | 'published' | 'hidden'
          thumbnail_url?: string | null
          views_count?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title_id?: string
          season_number?: number
          episode_number?: number
          episode_title?: string | null
          synopsis?: string | null
          duration_minutes?: number | null
          status?: 'draft' | 'processing' | 'published' | 'hidden'
          thumbnail_url?: string | null
          views_count?: number
          created_at?: string
          updated_at?: string
        }
      }
      assets: {
        Row: {
          id: string
          title_id: string | null
          episode_id: string | null
          asset_type: 'video' | 'audio' | 'subtitle' | 'thumbnail' | 'poster' | 'backdrop'
          file_path: string
          file_size: number | null
          mime_type: string | null
          language_code: string | null
          quality: string | null
          duration_seconds: number | null
          metadata: any
          processing_status: 'pending' | 'processing' | 'completed' | 'failed'
          created_at: string
        }
        Insert: {
          id?: string
          title_id?: string | null
          episode_id?: string | null
          asset_type: 'video' | 'audio' | 'subtitle' | 'thumbnail' | 'poster' | 'backdrop'
          file_path: string
          file_size?: number | null
          mime_type?: string | null
          language_code?: string | null
          quality?: string | null
          duration_seconds?: number | null
          metadata?: any
          processing_status?: 'pending' | 'processing' | 'completed' | 'failed'
          created_at?: string
        }
        Update: {
          id?: string
          title_id?: string | null
          episode_id?: string | null
          asset_type?: 'video' | 'audio' | 'subtitle' | 'thumbnail' | 'poster' | 'backdrop'
          file_path?: string
          file_size?: number | null
          mime_type?: string | null
          language_code?: string | null
          quality?: string | null
          duration_seconds?: number | null
          metadata?: any
          processing_status?: 'pending' | 'processing' | 'completed' | 'failed'
          created_at?: string
        }
      }
      renditions: {
        Row: {
          id: string
          title_id: string | null
          episode_id: string | null
          manifest_type: 'hls' | 'dash'
          manifest_url: string
          resolutions: string[]
          bitrates: number[]
          processing_status: 'pending' | 'processing' | 'completed' | 'failed'
          processing_progress: number
          error_message: string | null
          created_at: string
          completed_at: string | null
        }
        Insert: {
          id?: string
          title_id?: string | null
          episode_id?: string | null
          manifest_type: 'hls' | 'dash'
          manifest_url: string
          resolutions?: string[]
          bitrates?: number[]
          processing_status?: 'pending' | 'processing' | 'completed' | 'failed'
          processing_progress?: number
          error_message?: string | null
          created_at?: string
          completed_at?: string | null
        }
        Update: {
          id?: string
          title_id?: string | null
          episode_id?: string | null
          manifest_type?: 'hls' | 'dash'
          manifest_url?: string
          resolutions?: string[]
          bitrates?: number[]
          processing_status?: 'pending' | 'processing' | 'completed' | 'failed'
          processing_progress?: number
          error_message?: string | null
          created_at?: string
          completed_at?: string | null
        }
      }
      watch_progress: {
        Row: {
          id: string
          session_id: string
          title_id: string | null
          episode_id: string | null
          progress_seconds: number
          duration_seconds: number | null
          completed: boolean
          last_watched: string
        }
        Insert: {
          id?: string
          session_id: string
          title_id?: string | null
          episode_id?: string | null
          progress_seconds?: number
          duration_seconds?: number | null
          completed?: boolean
          last_watched?: string
        }
        Update: {
          id?: string
          session_id?: string
          title_id?: string | null
          episode_id?: string | null
          progress_seconds?: number
          duration_seconds?: number | null
          completed?: boolean
          last_watched?: string
        }
      }
    }
  }
}