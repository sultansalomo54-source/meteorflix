# StreamVault - Complete Streaming Platform

A modern streaming platform with admin content management system, built with Next.js, Supabase, and Shadcn-ui.

## 🎯 Features

### Viewer Experience
- **Homepage** - Featured content carousel and trending sections
- **Browse Catalog** - Advanced filtering by genre, year, type with pagination
- **Content Detail Pages** - Rich metadata, cast info, episodes for series
- **Video Streaming** - Full-screen player with progress tracking
- **Search & Discovery** - Real-time search with advanced filters

### Admin Experience
- **Dashboard** - Analytics, content overview, system statistics
- **Content Management** - Upload, edit, delete content with bulk operations
- **Episode Management** - Add/manage episodes for TV series
- **User Authentication** - Secure admin access with role-based permissions

## 🚀 Deployment to Hostinger

### Prerequisites
1. Hostinger hosting account with Node.js support
2. Supabase account (free tier available)
3. Domain configured in Hostinger

### Step 1: Setup Supabase
1. Go to [supabase.com](https://supabase.com) and create a new project
2. Go to Settings → API to get your project URL and anon key
3. Go to SQL Editor and run the migration file: `supabase/migrations/001_initial_schema.sql`
4. Go to Authentication → Users and create admin user:
   - Email: `deparideran@gmail.com`
   - Password: `Satu234**`
5. Go to your user profiles table and update the role to 'admin'

### Step 2: Environment Configuration
1. Copy `.env.example` to `.env.local`
2. Update the environment variables:

```bash
# Supabase Configuration (from your Supabase project)
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here

# Application Configuration
NEXT_PUBLIC_APP_URL=https://yourdomain.com
NEXT_PUBLIC_APP_NAME=StreamVault

# Security (generate a random secret)
NEXTAUTH_SECRET=your-random-secret-key-here
NEXTAUTH_URL=https://yourdomain.com
```

### Step 3: Install Dependencies
```bash
npm install
# or
pnpm install
```

### Step 4: Build the Application
```bash
npm run build
# or
pnpm run build
```

### Step 5: Deploy to Hostinger
1. Compress the entire project folder into a ZIP file
2. Upload to your Hostinger file manager in the `public_html` directory
3. Extract the files
4. Ensure your domain points to the `public_html` directory
5. If using subdomain, point to the extracted project folder

### Step 6: Configure Hostinger
1. In your Hostinger control panel, ensure Node.js is enabled
2. Set the Node.js version to 18+ 
3. Set the startup file to `server.js` or use the Next.js deployment method
4. Configure environment variables in Hostinger's environment settings

## 📱 Admin Access

**Login Credentials:**
- Email: `deparideran@gmail.com`
- Password: `Satu234**`

**Admin Panel:** `https://yourdomain.com/admin`

## 🛠 Development

### Local Development
```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

### Available Scripts
- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

## 📊 Database Schema

The platform uses Supabase (PostgreSQL) with the following main tables:
- `user_profiles` - User authentication and roles
- `titles` - Movies and series metadata
- `episodes` - TV series episodes
- `assets` - Media files (videos, images, subtitles)
- `watch_progress` - User viewing progress
- `collections` - Watchlists and favorites

## 🔐 Security Features

- Row Level Security (RLS) policies
- Role-based access control (admin/editor/viewer)
- Secure authentication with Supabase Auth
- Session-based progress tracking for anonymous users

## 🎨 Tech Stack

- **Frontend:** Next.js 14, React, TypeScript
- **UI Library:** Shadcn-ui, Tailwind CSS
- **Backend:** Supabase (PostgreSQL + Auth)
- **Video Player:** Custom HLS/DASH support
- **Deployment:** Hostinger, Vercel, or Netlify

## 📝 Content Management

### Adding Content
1. Login to admin panel (`/admin`)
2. Go to "Upload Content" 
3. Fill in metadata (title, synopsis, cast, etc.)
4. Upload media files (videos, images)
5. Publish when ready

### Managing Series
1. Create the series with type "TV Series"
2. Go to "Edit Content" → "Episodes" tab
3. Add episodes with season/episode numbers
4. Upload video files for each episode

## 🆘 Support

For issues or questions:
1. Check the admin dashboard for system status
2. Verify Supabase connection and database setup
3. Check environment variables configuration
4. Ensure all dependencies are installed

## 📜 License

This project is for personal/commercial use. All rights reserved.