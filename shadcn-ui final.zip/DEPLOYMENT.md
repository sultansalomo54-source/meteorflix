# StreamVault Deployment Guide for Hostinger

## 🎯 Quick Start

This guide will help you deploy StreamVault to your Hostinger hosting account.

## 📋 Pre-deployment Checklist

### Requirements
- [x] Hostinger hosting account (Business plan or higher recommended for Node.js)
- [x] Domain name configured in Hostinger
- [x] Supabase account (free)
- [x] FTP/File Manager access to Hostinger

## 🔧 Step-by-Step Deployment

### 1. Setup Supabase Backend

#### Create Supabase Project
1. Go to [supabase.com](https://supabase.com)
2. Click "Start your project" and sign up/login
3. Create a new project:
   - Name: `streamvault`
   - Database Password: (use a strong password)
   - Region: (choose closest to your users)

#### Configure Database
1. Go to **SQL Editor** in your Supabase dashboard
2. Copy and paste the entire contents of `supabase/migrations/001_initial_schema.sql`
3. Click "Run" to create all tables and policies

#### Create Admin User
1. Go to **Authentication** → **Users**
2. Click "Add user" (manually)
3. Enter:
   - Email: `deparideran@gmail.com`
   - Password: `Satu234**`
   - Confirm password: `Satu234**`
4. Check "Auto Confirm User"
5. Click "Create user"

#### Set Admin Role
1. Go to **Table Editor** → **user_profiles**
2. Click "Insert" → "Insert row"
3. Fill in:
   - `id`: (copy the user ID from Authentication → Users)
   - `email`: `deparideran@gmail.com`
   - `role`: `admin`
   - Leave other fields as default
4. Click "Save"

#### Get API Keys
1. Go to **Settings** → **API**
2. Copy these values (you'll need them later):
   - Project URL: `https://xxxxx.supabase.co`
   - Anon/Public Key: `eyJhbGci...`

### 2. Prepare Application Files

#### Environment Configuration
1. Copy `.env.example` to `.env.local`
2. Update with your Supabase credentials:

```bash
# Replace with your Supabase project details
NEXT_PUBLIC_SUPABASE_URL=https://your-project-id.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Replace with your domain
NEXT_PUBLIC_APP_URL=https://yourdomain.com
NEXT_PUBLIC_APP_NAME=StreamVault

# Generate a random secret (you can use: openssl rand -base64 32)
NEXTAUTH_SECRET=your-random-32-character-secret-here
NEXTAUTH_URL=https://yourdomain.com

NODE_ENV=production
```

### 3. Build Application

#### Install Dependencies
```bash
npm install
```

#### Build for Production
```bash
npm run build
```

### 4. Deploy to Hostinger

#### Method 1: File Manager (Recommended)
1. Compress your entire project into a ZIP file
2. Login to Hostinger hPanel
3. Go to **File Manager**
4. Navigate to `public_html` (or your domain's folder)
5. Upload the ZIP file
6. Extract it in place
7. The folder structure should be:
   ```
   public_html/
   ├── .next/
   ├── app/
   ├── components/
   ├── lib/
   ├── public/
   ├── supabase/
   ├── package.json
   ├── next.config.js
   └── ...other files
   ```

#### Method 2: FTP Upload
1. Use FTP client (FileZilla, WinSCP, etc.)
2. Connect to your Hostinger FTP:
   - Host: your-domain.com
   - Username: (from Hostinger hPanel)
   - Password: (from Hostinger hPanel)
3. Upload all files to `public_html`

### 5. Configure Hostinger Environment

#### Enable Node.js (Business Plan Required)
1. In hPanel, go to **Advanced** → **Node.js**
2. Enable Node.js
3. Set Node.js version to **18.x** or higher
4. Set App root to `/public_html` (or your project folder)
5. Set Startup file to `server.js`

#### Set Environment Variables
1. In Node.js settings, add environment variables:
   ```
   NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...
   NEXT_PUBLIC_APP_URL=https://yourdomain.com
   NEXTAUTH_SECRET=your-secret-here
   NODE_ENV=production
   ```

#### Install Dependencies on Server
1. In Hostinger Node.js panel, click "Run npm install"
2. Wait for installation to complete

### 6. Alternative: Static Export (Shared Hosting)

If you don't have Node.js support, use static export:

#### Modify next.config.js
```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  trailingSlash: true,
  images: {
    unoptimized: true
  }
}

module.exports = nextConfig
```

#### Build Static Site
```bash
npm run build
```

#### Upload Only the `out` Folder
1. After building, upload contents of the `out` folder to `public_html`
2. This creates a static version without server-side features

### 7. Testing Deployment

#### Verify Website
1. Visit your domain: `https://yourdomain.com`
2. Check that homepage loads correctly
3. Test navigation to browse page

#### Test Admin Access
1. Go to: `https://yourdomain.com/auth/login`
2. Login with:
   - Email: `deparideran@gmail.com`
   - Password: `Satu234**`
3. Verify admin dashboard loads
4. Test uploading content

## 🚨 Troubleshooting

### Common Issues

#### "Internal Server Error"
- Check Node.js is enabled and correct version
- Verify environment variables are set
- Check file permissions (755 for folders, 644 for files)

#### "Supabase Connection Error"
- Verify Supabase URL and API key
- Check if Supabase project is active
- Ensure environment variables match exactly

#### "Admin Login Fails"
- Verify user exists in Supabase Authentication
- Check user role is set to 'admin' in user_profiles table
- Confirm password is correct

#### "Pages Don't Load"
- Clear browser cache
- Check .htaccess file for redirect rules
- Verify all files uploaded correctly

### Getting Help
1. Check Hostinger error logs in hPanel
2. Check browser console for JavaScript errors
3. Verify Supabase logs in dashboard
4. Test locally first with `npm run dev`

## 📊 Performance Tips

### Optimization
1. Enable Cloudflare in Hostinger (free)
2. Compress images before upload
3. Use WebP format for images when possible
4. Enable GZIP compression in .htaccess

### Monitoring
1. Set up Supabase monitoring
2. Check Hostinger bandwidth usage
3. Monitor loading speeds with Google PageSpeed

## 🔒 Security

### Production Checklist
- [x] Admin credentials updated
- [x] Environment variables secured
- [x] HTTPS enabled (automatic with Hostinger)
- [x] Database RLS policies active
- [x] Strong passwords used

Your StreamVault platform is now ready for production use!