'use client'

import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'

export interface Title {
  id: string
  title: string
  slug: string
  type: 'movie' | 'series'
  synopsis: string | null
  year: number | null
  country: string | null
  genres: string[]
  cast_members: string[]
  tags: string[]
  internal_rating: number | null
  duration_minutes: number | null
  status: 'draft' | 'processing' | 'published' | 'hidden'
  poster_url: string | null
  backdrop_url: string | null
  trailer_url: string | null
  trailer_type: 'youtube' | 'vimeo' | 'mp4' | 'external' | null
  views_count: number
  featured: boolean
  created_at: string
  updated_at: string
}

export interface Episode {
  id: string
  title_id: string
  season_number: number
  episode_number: number
  episode_title: string | null
  synopsis: string | null
  duration_minutes: number | null
  status: 'draft' | 'processing' | 'published' | 'hidden'
  thumbnail_url: string | null
  views_count: number
  created_at: string
  updated_at: string
}

export function useTitles(filters?: {
  status?: string
  type?: string
  genre?: string
  search?: string
  page?: number
  limit?: number
}) {
  const [titles, setTitles] = useState<Title[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [totalCount, setTotalCount] = useState(0)

  useEffect(() => {
    fetchTitles()
  }, [filters])

  const fetchTitles = async () => {
    try {
      setLoading(true)
      let query = supabase
        .from('titles')
        .select('*', { count: 'exact' })

      // Apply filters
      if (filters?.status && filters.status !== 'all') {
        query = query.eq('status', filters.status)
      }

      if (filters?.type && filters.type !== 'all') {
        query = query.eq('type', filters.type)
      }

      if (filters?.genre) {
        query = query.contains('genres', [filters.genre])
      }

      if (filters?.search) {
        query = query.or(`title.ilike.%${filters.search}%,synopsis.ilike.%${filters.search}%`)
      }

      // Apply pagination
      const page = filters?.page || 1
      const limit = filters?.limit || 20
      const from = (page - 1) * limit
      const to = from + limit - 1

      query = query
        .range(from, to)
        .order('created_at', { ascending: false })

      const { data, error: fetchError, count } = await query

      if (fetchError) throw fetchError

      setTitles(data || [])
      setTotalCount(count || 0)
      setError(null)
    } catch (err) {
      console.error('Error fetching titles:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch titles')
    } finally {
      setLoading(false)
    }
  }

  const createTitle = async (titleData: Partial<Title>) => {
    try {
      const { data, error } = await supabase
        .from('titles')
        .insert([titleData])
        .select()
        .single()

      if (error) throw error

      setTitles(prev => [data, ...prev])
      return data
    } catch (err) {
      console.error('Error creating title:', err)
      throw err
    }
  }

  const updateTitle = async (id: string, updates: Partial<Title>) => {
    try {
      const { data, error } = await supabase
        .from('titles')
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq('id', id)
        .select()
        .single()

      if (error) throw error

      setTitles(prev => prev.map(title => 
        title.id === id ? { ...title, ...data } : title
      ))
      return data
    } catch (err) {
      console.error('Error updating title:', err)
      throw err
    }
  }

  const deleteTitle = async (id: string) => {
    try {
      const { error } = await supabase
        .from('titles')
        .delete()
        .eq('id', id)

      if (error) throw error

      setTitles(prev => prev.filter(title => title.id !== id))
    } catch (err) {
      console.error('Error deleting title:', err)
      throw err
    }
  }

  const publishTitle = async (id: string) => {
    return updateTitle(id, { status: 'published' })
  }

  const hideTitle = async (id: string) => {
    return updateTitle(id, { status: 'hidden' })
  }

  return {
    titles,
    loading,
    error,
    totalCount,
    totalPages: Math.ceil(totalCount / (filters?.limit || 20)),
    createTitle,
    updateTitle,
    deleteTitle,
    publishTitle,
    hideTitle,
    refetch: fetchTitles,
  }
}

export function useTitle(id: string) {
  const [title, setTitle] = useState<Title | null>(null)
  const [episodes, setEpisodes] = useState<Episode[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (id) {
      fetchTitle()
    }
  }, [id])

  const fetchTitle = async () => {
    try {
      setLoading(true)

      // Fetch title
      const { data: titleData, error: titleError } = await supabase
        .from('titles')
        .select('*')
        .eq('id', id)
        .single()

      if (titleError) throw titleError

      setTitle(titleData)

      // Fetch episodes if it's a series
      if (titleData.type === 'series') {
        const { data: episodesData, error: episodesError } = await supabase
          .from('episodes')
          .select('*')
          .eq('title_id', id)
          .order('season_number')
          .order('episode_number')

        if (episodesError) throw episodesError

        setEpisodes(episodesData || [])
      }

      setError(null)
    } catch (err) {
      console.error('Error fetching title:', err)
      setError(err instanceof Error ? err.message : 'Failed to fetch title')
    } finally {
      setLoading(false)
    }
  }

  return {
    title,
    episodes,
    loading,
    error,
    refetch: fetchTitle,
  }
}