'use client'

import { useState, useCallback, useRef } from 'react'
import { useDropzone } from 'react-dropzone'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { Progress } from '@/components/ui/progress'
import { Badge } from '@/components/ui/badge'
import { 
  Upload, 
  FileVideo, 
  FileAudio, 
  FileText, 
  X, 
  Check,
  AlertCircle
} from 'lucide-react'
import { formatFileSize, VIDEO_EXTENSIONS, AUDIO_EXTENSIONS, SUBTITLE_EXTENSIONS } from '@/lib/utils'
import { supabase } from '@/lib/supabase'

interface UploadFile {
  id: string
  file: File
  progress: number
  status: 'pending' | 'uploading' | 'completed' | 'error'
  error?: string
  uploadId?: string
  url?: string
}

interface UploadDropzoneProps {
  titleId: string
  onUploadComplete?: (files: UploadFile[]) => void
  acceptedTypes?: string[]
  maxFiles?: number
  maxSize?: number
}

export function UploadDropzone({
  titleId,
  onUploadComplete,
  acceptedTypes = [...VIDEO_EXTENSIONS, ...AUDIO_EXTENSIONS, ...SUBTITLE_EXTENSIONS],
  maxFiles = 10,
  maxSize = 5 * 1024 * 1024 * 1024 // 5GB
}: UploadDropzoneProps) {
  const [uploadFiles, setUploadFiles] = useState<UploadFile[]>([])
  const [isDragging, setIsDragging] = useState(false)
  const uploadRefs = useRef<{ [key: string]: AbortController }>({})

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const newFiles: UploadFile[] = acceptedFiles.map(file => ({
      id: Math.random().toString(36),
      file,
      progress: 0,
      status: 'pending'
    }))

    setUploadFiles(prev => [...prev, ...newFiles])
    
    // Start uploading files
    newFiles.forEach(uploadFile => {
      uploadFileToSupabase(uploadFile)
    })
  }, [titleId])

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'video/*': VIDEO_EXTENSIONS,
      'audio/*': AUDIO_EXTENSIONS,
      'text/*': SUBTITLE_EXTENSIONS
    },
    maxFiles: maxFiles - uploadFiles.length,
    maxSize,
    onDragEnter: () => setIsDragging(true),
    onDragLeave: () => setIsDragging(false),
    onDropAccepted: () => setIsDragging(false),
    onDropRejected: () => setIsDragging(false)
  })

  const uploadFileToSupabase = async (uploadFile: UploadFile) => {
    const controller = new AbortController()
    uploadRefs.current[uploadFile.id] = controller

    try {
      // Update status to uploading
      setUploadFiles(prev => prev.map(f => 
        f.id === uploadFile.id 
          ? { ...f, status: 'uploading' as const }
          : f
      ))

      // Create file path
      const fileExt = uploadFile.file.name.split('.').pop()
      const fileName = `${titleId}/${Date.now()}-${uploadFile.file.name}`
      const filePath = `uploads/${fileName}`

      // Upload to Supabase Storage
      const { data, error } = await supabase.storage
        .from('media')
        .upload(filePath, uploadFile.file, {
          cacheControl: '3600',
          upsert: false,
        })

      if (error) throw error

      // Simulate progress for demo (in real implementation, use TUS for resumable uploads)
      const progressInterval = setInterval(() => {
        setUploadFiles(prev => prev.map(f => {
          if (f.id === uploadFile.id && f.progress < 100) {
            const newProgress = Math.min(f.progress + Math.random() * 20, 100)
            if (newProgress >= 100) {
              clearInterval(progressInterval)
            }
            return { ...f, progress: newProgress }
          }
          return f
        }))
      }, 200)

      // Get public URL
      const { data: urlData } = supabase.storage
        .from('media')
        .getPublicUrl(data.path)

      // Save asset record to database
      const assetType = VIDEO_EXTENSIONS.some(ext => uploadFile.file.name.toLowerCase().endsWith(ext))
        ? 'video'
        : AUDIO_EXTENSIONS.some(ext => uploadFile.file.name.toLowerCase().endsWith(ext))
        ? 'audio'
        : 'subtitle'

      const { error: dbError } = await supabase
        .from('assets')
        .insert({
          title_id: titleId,
          asset_type: assetType,
          file_path: data.path,
          file_size: uploadFile.file.size,
          mime_type: uploadFile.file.type,
          processing_status: 'pending'
        })

      if (dbError) throw dbError

      // Update file status to completed
      setUploadFiles(prev => prev.map(f => 
        f.id === uploadFile.id 
          ? { 
              ...f, 
              status: 'completed' as const, 
              progress: 100,
              url: urlData.publicUrl 
            }
          : f
      ))

    } catch (error: any) {
      console.error('Upload error:', error)
      
      setUploadFiles(prev => prev.map(f => 
        f.id === uploadFile.id 
          ? { 
              ...f, 
              status: 'error' as const, 
              error: error.message || 'Upload failed' 
            }
          : f
      ))
    }
  }

  const removeFile = (id: string) => {
    // Cancel upload if in progress
    if (uploadRefs.current[id]) {
      uploadRefs.current[id].abort()
      delete uploadRefs.current[id]
    }

    setUploadFiles(prev => prev.filter(f => f.id !== id))
  }

  const retryUpload = (uploadFile: UploadFile) => {
    setUploadFiles(prev => prev.map(f => 
      f.id === uploadFile.id 
        ? { ...f, status: 'pending', progress: 0, error: undefined }
        : f
    ))
    
    uploadFileToSupabase(uploadFile)
  }

  const getFileIcon = (fileName: string) => {
    const name = fileName.toLowerCase()
    if (VIDEO_EXTENSIONS.some(ext => name.endsWith(ext))) {
      return <FileVideo className="h-5 w-5" />
    }
    if (AUDIO_EXTENSIONS.some(ext => name.endsWith(ext))) {
      return <FileAudio className="h-5 w-5" />
    }
    if (SUBTITLE_EXTENSIONS.some(ext => name.endsWith(ext))) {
      return <FileText className="h-5 w-5" />
    }
    return <FileVideo className="h-5 w-5" />
  }

  const getStatusColor = (status: UploadFile['status']) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500'
      case 'uploading':
        return 'bg-blue-500'
      case 'error':
        return 'bg-red-500'
      default:
        return 'bg-gray-500'
    }
  }

  const completedFiles = uploadFiles.filter(f => f.status === 'completed')
  
  // Call onUploadComplete when all files are processed
  if (completedFiles.length > 0 && completedFiles.length === uploadFiles.length) {
    onUploadComplete?.(completedFiles)
  }

  return (
    <div className="space-y-4">
      {/* Dropzone */}
      <Card>
        <CardContent className="p-6">
          <div
            {...getRootProps()}
            className={`
              border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
              ${isDragActive || isDragging 
                ? 'border-primary bg-primary/5' 
                : 'border-muted-foreground/25 hover:border-primary/50'
              }
            `}
          >
            <input {...getInputProps()} />
            <Upload className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            <div className="space-y-2">
              <p className="text-lg font-medium">
                {isDragActive ? 'Drop files here' : 'Drop files here or click to browse'}
              </p>
              <p className="text-sm text-muted-foreground">
                Supports video ({VIDEO_EXTENSIONS.join(', ')}), audio ({AUDIO_EXTENSIONS.join(', ')}), 
                and subtitle ({SUBTITLE_EXTENSIONS.join(', ')}) files
              </p>
              <p className="text-xs text-muted-foreground">
                Max file size: {formatFileSize(maxSize)} • Max {maxFiles} files
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upload Progress */}
      {uploadFiles.length > 0 && (
        <div className="space-y-3">
          <h3 className="font-medium">Upload Progress</h3>
          {uploadFiles.map((uploadFile) => (
            <Card key={uploadFile.id}>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <div className="text-muted-foreground">
                    {getFileIcon(uploadFile.file.name)}
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-sm font-medium truncate">
                        {uploadFile.file.name}
                      </p>
                      <div className="flex items-center gap-2">
                        <Badge 
                          variant="outline"
                          className={`text-xs ${getStatusColor(uploadFile.status)}`}
                        >
                          {uploadFile.status}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {formatFileSize(uploadFile.file.size)}
                        </span>
                      </div>
                    </div>
                    
                    {uploadFile.status === 'uploading' && (
                      <Progress value={uploadFile.progress} className="h-2" />
                    )}
                    
                    {uploadFile.error && (
                      <div className="flex items-center gap-2 mt-1">
                        <AlertCircle className="h-4 w-4 text-red-500" />
                        <span className="text-xs text-red-500">{uploadFile.error}</span>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-1">
                    {uploadFile.status === 'completed' && (
                      <Check className="h-4 w-4 text-green-500" />
                    )}
                    
                    {uploadFile.status === 'error' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => retryUpload(uploadFile)}
                      >
                        Retry
                      </Button>
                    )}
                    
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => removeFile(uploadFile.id)}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}