'use client'

import Image from 'next/image'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent } from '@/components/ui/card'
import { formatDuration } from '@/lib/utils'
import { Title } from '@/hooks/use-titles'
import { Play, Star } from 'lucide-react'

interface ContentGridProps {
  titles: Title[]
  loading?: boolean
  emptyMessage?: string
}

export function ContentGrid({ 
  titles, 
  loading = false, 
  emptyMessage = "No content found" 
}: ContentGridProps) {
  if (loading) {
    return (
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4">
        {Array.from({ length: 12 }).map((_, i) => (
          <ContentCardSkeleton key={i} />
        ))}
      </div>
    )
  }

  if (titles.length === 0) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">{emptyMessage}</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 2xl:grid-cols-6 gap-4">
      {titles.map((title) => (
        <ContentCard key={title.id} title={title} />
      ))}
    </div>
  )
}

function ContentCard({ title }: { title: Title }) {
  const posterUrl = title.poster_url || '/images/Placeholder.jpg'
  
  return (
    <Link href={`/title/${title.slug}`}>
      <Card className="group cursor-pointer overflow-hidden transition-transform hover:scale-105">
        <div className="relative aspect-[2/3]">
          <Image
            src={posterUrl}
            alt={title.title}
            fill
            className="object-cover transition-transform group-hover:scale-110"
            sizes="(max-width: 768px) 50vw, (max-width: 1200px) 33vw, 20vw"
          />
          
          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
            <div className="bg-white/20 backdrop-blur-sm rounded-full p-3">
              <Play className="h-6 w-6 text-white fill-white" />
            </div>
          </div>

          {/* Featured badge */}
          {title.featured && (
            <Badge className="absolute top-2 left-2 bg-red-600 hover:bg-red-700">
              Featured
            </Badge>
          )}

          {/* Rating */}
          {title.internal_rating && (
            <div className="absolute top-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-sm flex items-center gap-1">
              <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
              {title.internal_rating.toFixed(1)}
            </div>
          )}

          {/* Type badge */}
          <Badge 
            variant="secondary" 
            className="absolute bottom-2 left-2 text-xs"
          >
            {title.type === 'movie' ? 'Movie' : 'Series'}
          </Badge>
        </div>

        <CardContent className="p-3">
          <h3 className="font-semibold text-sm line-clamp-2 mb-1">
            {title.title}
          </h3>
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span>{title.year}</span>
            {title.duration_minutes && (
              <>
                <span>•</span>
                <span>{formatDuration(title.duration_minutes)}</span>
              </>
            )}
          </div>

          {title.genres.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {title.genres.slice(0, 2).map((genre) => (
                <Badge 
                  key={genre} 
                  variant="outline" 
                  className="text-xs px-1 py-0"
                >
                  {genre}
                </Badge>
              ))}
              {title.genres.length > 2 && (
                <Badge variant="outline" className="text-xs px-1 py-0">
                  +{title.genres.length - 2}
                </Badge>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </Link>
  )
}

function ContentCardSkeleton() {
  return (
    <Card className="overflow-hidden">
      <div className="relative aspect-[2/3] bg-muted animate-pulse" />
      <CardContent className="p-3 space-y-2">
        <div className="h-4 bg-muted rounded animate-pulse" />
        <div className="h-3 bg-muted rounded w-2/3 animate-pulse" />
        <div className="flex gap-1">
          <div className="h-5 bg-muted rounded w-12 animate-pulse" />
          <div className="h-5 bg-muted rounded w-16 animate-pulse" />
        </div>
      </CardContent>
    </Card>
  )
}