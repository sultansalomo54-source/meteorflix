'use client'

import { useState, useRef, useEffect } from 'react'
import { Search, X } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import { supabase } from '@/lib/supabase'
import { Title } from '@/hooks/use-titles'
import { useRouter } from 'next/navigation'
import { GENRES } from '@/lib/utils'

interface SearchBarProps {
  onSearch?: (query: string, filters: SearchFilters) => void
  placeholder?: string
  showFilters?: boolean
}

interface SearchFilters {
  genres: string[]
  year: string
  type: string
}

export function SearchBar({ 
  onSearch, 
  placeholder = "Search movies and series...",
  showFilters = true 
}: SearchBarProps) {
  const [query, setQuery] = useState('')
  const [suggestions, setSuggestions] = useState<Title[]>([])
  const [showSuggestions, setShowSuggestions] = useState(false)
  const [loading, setLoading] = useState(false)
  const [filters, setFilters] = useState<SearchFilters>({
    genres: [],
    year: '',
    type: ''
  })
  const router = useRouter()
  const inputRef = useRef<HTMLInputElement>(null)

  // Debounced search for suggestions
  useEffect(() => {
    const timeoutId = setTimeout(() => {
      if (query.length >= 2) {
        fetchSuggestions(query)
      } else {
        setSuggestions([])
        setShowSuggestions(false)
      }
    }, 300)

    return () => clearTimeout(timeoutId)
  }, [query])

  const fetchSuggestions = async (searchQuery: string) => {
    try {
      setLoading(true)
      const { data, error } = await supabase
        .from('titles')
        .select('id, title, slug, year, type, poster_url, genres')
        .eq('status', 'published')
        .or(`title.ilike.%${searchQuery}%,synopsis.ilike.%${searchQuery}%`)
        .limit(8)

      if (error) throw error

      setSuggestions(data || [])
      setShowSuggestions(true)
    } catch (error) {
      console.error('Error fetching suggestions:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = () => {
    if (query.trim()) {
      onSearch?.(query, filters)
      router.push(`/search?q=${encodeURIComponent(query.trim())}`)
      setShowSuggestions(false)
    }
  }

  const handleSuggestionClick = (title: Title) => {
    router.push(`/title/${title.slug}`)
    setShowSuggestions(false)
    setQuery('')
  }

  const addGenreFilter = (genre: string) => {
    if (!filters.genres.includes(genre)) {
      const newFilters = {
        ...filters,
        genres: [...filters.genres, genre]
      }
      setFilters(newFilters)
      onSearch?.(query, newFilters)
    }
  }

  const removeGenreFilter = (genre: string) => {
    const newFilters = {
      ...filters,
      genres: filters.genres.filter(g => g !== genre)
    }
    setFilters(newFilters)
    onSearch?.(query, newFilters)
  }

  const setTypeFilter = (type: string) => {
    const newFilters = { ...filters, type }
    setFilters(newFilters)
    onSearch?.(query, newFilters)
  }

  const clearFilters = () => {
    const newFilters = { genres: [], year: '', type: '' }
    setFilters(newFilters)
    onSearch?.(query, newFilters)
  }

  const hasActiveFilters = filters.genres.length > 0 || filters.year || filters.type

  return (
    <div className="w-full max-w-2xl mx-auto">
      {/* Search Input */}
      <div className="relative">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
          <Input
            ref={inputRef}
            type="text"
            placeholder={placeholder}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                handleSearch()
              } else if (e.key === 'Escape') {
                setShowSuggestions(false)
              }
            }}
            onFocus={() => {
              if (suggestions.length > 0) {
                setShowSuggestions(true)
              }
            }}
            className="pl-10 pr-10"
          />
          {query && (
            <Button
              variant="ghost"
              size="icon"
              className="absolute right-1 top-1/2 transform -translate-y-1/2 h-8 w-8"
              onClick={() => {
                setQuery('')
                setSuggestions([])
                setShowSuggestions(false)
                inputRef.current?.focus()
              }}
            >
              <X className="h-4 w-4" />
            </Button>
          )}
        </div>

        {/* Suggestions Dropdown */}
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute top-full left-0 right-0 bg-background border rounded-md shadow-lg z-50 mt-1">
            <div className="max-h-80 overflow-y-auto">
              {suggestions.map((title) => (
                <button
                  key={title.id}
                  className="w-full p-3 text-left hover:bg-muted transition-colors flex items-center gap-3"
                  onClick={() => handleSuggestionClick(title)}
                >
                  <div className="w-8 h-12 bg-muted rounded flex-shrink-0">
                    {title.poster_url && (
                      <img
                        src={title.poster_url}
                        alt={title.title}
                        className="w-full h-full object-cover rounded"
                      />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-medium truncate">{title.title}</div>
                    <div className="text-sm text-muted-foreground flex items-center gap-2">
                      <span>{title.year}</span>
                      <span>•</span>
                      <span className="capitalize">{title.type}</span>
                      {title.genres.length > 0 && (
                        <>
                          <span>•</span>
                          <span className="truncate">{title.genres.slice(0, 2).join(', ')}</span>
                        </>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="flex flex-wrap items-center gap-2 mt-3">
          {/* Genre Filter */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm">
                Genres {filters.genres.length > 0 && `(${filters.genres.length})`}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="p-0" align="start">
              <Command>
                <CommandInput placeholder="Search genres..." />
                <CommandList>
                  <CommandEmpty>No genres found.</CommandEmpty>
                  <CommandGroup>
                    {GENRES.map((genre) => (
                      <CommandItem
                        key={genre}
                        onSelect={() => {
                          if (filters.genres.includes(genre)) {
                            removeGenreFilter(genre)
                          } else {
                            addGenreFilter(genre)
                          }
                        }}
                      >
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={filters.genres.includes(genre)}
                            readOnly
                          />
                          {genre}
                        </div>
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>

          {/* Type Filter */}
          <Popover>
            <PopoverTrigger asChild>
              <Button variant="outline" size="sm">
                Type {filters.type && `(${filters.type})`}
              </Button>
            </PopoverTrigger>
            <PopoverContent className="p-0" align="start">
              <Command>
                <CommandList>
                  <CommandGroup>
                    <CommandItem onSelect={() => setTypeFilter('')}>
                      All Types
                    </CommandItem>
                    <CommandItem onSelect={() => setTypeFilter('movie')}>
                      Movies
                    </CommandItem>
                    <CommandItem onSelect={() => setTypeFilter('series')}>
                      Series
                    </CommandItem>
                  </CommandGroup>
                </CommandList>
              </Command>
            </PopoverContent>
          </Popover>

          {/* Clear Filters */}
          {hasActiveFilters && (
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={clearFilters}
              className="text-muted-foreground"
            >
              Clear all
            </Button>
          )}
        </div>
      )}

      {/* Active Filter Badges */}
      {hasActiveFilters && (
        <div className="flex flex-wrap gap-1 mt-2">
          {filters.genres.map((genre) => (
            <Badge key={genre} variant="secondary" className="text-xs">
              {genre}
              <button
                onClick={() => removeGenreFilter(genre)}
                className="ml-1 hover:bg-destructive/20 rounded-full"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          ))}
          {filters.type && (
            <Badge variant="secondary" className="text-xs">
              {filters.type}
              <button
                onClick={() => setTypeFilter('')}
                className="ml-1 hover:bg-destructive/20 rounded-full"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
        </div>
      )}
    </div>
  )
}